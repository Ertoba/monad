import { redirect } from "next/navigation"

export default function ReferralPage() {
  redirect("/profile")
}

